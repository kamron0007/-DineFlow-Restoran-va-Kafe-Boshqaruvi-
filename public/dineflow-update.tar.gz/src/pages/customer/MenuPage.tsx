import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { CustomerHeader } from '../../components/CustomerHeader';
import { CustomerBottomNav } from '../../components/CustomerBottomNav';
import { DishCard } from '../../components/DishCard';
import { DishDetailModal } from '../../components/DishDetailModal';
import { QrScannerModal } from '../../components/QrScannerModal';
import { MenuItem } from '../../types';
import { formatUZS } from '../../utils/formatters';
import {
  Search,
  X,
  ShoppingBag,
  ArrowRight,
  Utensils,
  QrCode,
  UserCheck,
  MapPin,
  Bell,
} from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';

export const MenuPage: React.FC = () => {
  const {
    categories,
    menuItems,
    tables,
    waiters,
    activeTableNumber,
    setActiveTableNumber,
    callWaiter,
    cart,
    cartTotal,
    cartItemCount,
  } = useApp();
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('cat-all');
  const [selectedTier, setSelectedTier] = useState<'all' | 'oddiy' | 'biznes' | 'vip'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);
  const [isQrModalOpen, setIsQrModalOpen] = useState<boolean>(false);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Automatically detect table number from scanned QR URL (?table=N)
  useEffect(() => {
    const tableParam = searchParams.get('table');
    if (tableParam) {
      const parsed = parseInt(tableParam, 10);
      if (!isNaN(parsed) && parsed > 0 && parsed !== activeTableNumber) {
        setActiveTableNumber(parsed);
      }
    }
  }, [searchParams, activeTableNumber, setActiveTableNumber]);

  const currentTable = useMemo(() => {
    return tables.find((t) => t.table_number === activeTableNumber) || null;
  }, [tables, activeTableNumber]);

  const assignedWaiter = useMemo(() => {
    return (
      waiters.find((w) => w.assigned_tables?.includes(activeTableNumber)) || null
    );
  }, [waiters, activeTableNumber]);

  const zoneLabel = useMemo(() => {
    if (!currentTable) return 'Asosiy zal';
    if (currentTable.zone === 'vip' || currentTable.tier === 'vip') return 'VIP Xona';
    if (currentTable.zone === 'terrace' || currentTable.tier === 'biznes')
      return 'Biznes / Veranda';
    return 'Asosiy zal';
  }, [currentTable]);

  // Filter dishes
  const filteredDishes = useMemo(() => {
    return menuItems.filter((dish) => {
      const matchesCategory =
        selectedCategoryId === 'cat-all' || dish.category_id === selectedCategoryId;
      const matchesTier = selectedTier === 'all' || dish.tier === selectedTier;
      const matchesSearch =
        searchQuery.trim() === '' ||
        dish.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        dish.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesTier && matchesSearch;
    });
  }, [menuItems, selectedCategoryId, selectedTier, searchQuery]);

  return (
    <div className="min-h-screen bg-[#FAF8F3] pb-28 md:pb-12 flex flex-col">
      <CustomerHeader />

      <main className="flex-1 max-w-4xl mx-auto w-full px-4 pt-3">
        {/* STOL PASPORTI (Automatic Table Passport & QR Scanner Trigger) */}
        <div className="mb-3 bg-white rounded-2xl border border-[#E5E0D8] p-3.5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-12 h-12 rounded-2xl bg-[#173F35] text-white flex flex-col items-center justify-center shrink-0 shadow-xs">
              <span className="text-[9px] uppercase tracking-wider text-amber-300 font-bold leading-none">
                STOL
              </span>
              <span className="font-mono font-extrabold text-base tabular-nums leading-tight mt-0.5">
                №{activeTableNumber}
              </span>
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-xs text-[#737A75] flex-wrap">
                <span className="font-display font-bold text-sm text-[#202622]">
                  Siz №{activeTableNumber}-stoldasiz
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-medium text-[#173F35]">{zoneLabel}</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">{currentTable?.seats || 4} o'rinli</span>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-[#737A75] mt-0.5 truncate">
                <UserCheck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                <span>Mas'ul ofitsiant:</span>
                <span className="font-semibold text-[#173F35] truncate">
                  {assignedWaiter
                    ? `${assignedWaiter.badge_id} · ${assignedWaiter.full_name}`
                    : currentTable?.assigned_waiter_name || 'Karimov Dilshod'}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => callWaiter()}
              className="px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold flex items-center gap-1.5 transition-colors whitespace-nowrap"
            >
              <Bell className="w-3.5 h-3.5 text-amber-700" />
              <span>Chaqirish</span>
            </button>

            <button
              type="button"
              onClick={() => setIsQrModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-[#173F35] hover:bg-[#235B4E] text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs whitespace-nowrap"
            >
              <QrCode className="w-3.5 h-3.5 text-amber-400" />
              <span>QR Kod / Skaner</span>
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative mb-3">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#737A75]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Taom nomi yoki tarkibi bo'yicha qidiruv..."
            className="w-full pl-10 pr-10 py-3 rounded-2xl bg-white border border-[#E5E0D8] text-sm text-[#202622] placeholder:text-[#737A75] focus:outline-none focus:border-[#173F35] focus:ring-1 focus:ring-[#173F35] shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#737A75] hover:text-[#202622] p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category Horizontal Filter Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 mb-2 no-scrollbar scroll-smooth">
          {categories.map((cat) => {
            const isSelected = selectedCategoryId === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategoryId(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#173F35] text-white shadow-sm'
                    : 'bg-white text-[#737A75] hover:text-[#202622] border border-[#E5E0D8]'
                }`}
              >
                <span>{cat.name}</span>
              </button>
            );
          })}
        </div>

        {/* Dish Tier Filter Bar: Oddiy / Biznes / VIP */}
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#E5E0D8]/60 gap-2 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold text-[#737A75] uppercase tracking-wider mr-1 hidden sm:inline">
              Turi:
            </span>
            {[
              { id: 'all', label: 'Barcha turlar' },
              { id: 'oddiy', label: 'Oddiy' },
              { id: 'biznes', label: 'Biznes' },
              { id: 'vip', label: 'VIP' },
            ].map((t) => {
              const active = selectedTier === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setSelectedTier(t.id as any)}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                    active
                      ? t.id === 'vip'
                        ? 'bg-amber-500 text-slate-950 shadow-xs'
                        : t.id === 'biznes'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : t.id === 'oddiy'
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : 'bg-[#173F35] text-white shadow-xs'
                      : 'bg-white text-[#737A75] border border-[#E5E0D8] hover:border-[#173F35]'
                  }`}
                >
                  {t.label}
                </button>
              );
            })}
          </div>

          <span className="text-xs text-[#737A75] whitespace-nowrap tabular-nums">
            {filteredDishes.length} ta taom
          </span>
        </div>

        {/* Menu Grid Header */}
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-bold text-lg text-[#202622]">
            {categories.find((c) => c.id === selectedCategoryId)?.name || 'Barcha taomlar'}
            {selectedTier !== 'all' && (
              <span className="text-xs font-bold text-[#173F35] ml-2">
                ({selectedTier === 'vip' ? 'VIP' : selectedTier === 'biznes' ? 'Biznes' : 'Oddiy'})
              </span>
            )}
          </h2>
        </div>

        {/* Dishes Grid */}
        {filteredDishes.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
            {filteredDishes.map((dish) => (
              <DishCard key={dish.id} dish={dish} onSelect={(d) => setSelectedDish(d)} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl border border-[#E5E0D8] p-10 text-center my-6">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3 text-slate-500">
              <Utensils className="w-6 h-6" />
            </div>
            <h3 className="font-display font-semibold text-base text-[#202622] mb-1">
              Taom topilmadi
            </h3>
            <p className="text-xs text-[#737A75] mb-4">
              "{searchQuery}" so'rovi bo'yicha hech qanday taom mavjud emas.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategoryId('cat-all');
              }}
              className="px-4 py-2 rounded-xl bg-[#173F35] text-white text-xs font-semibold hover:bg-[#235B4E] transition-colors"
            >
              Barcha taomlarni ko'rsatish
            </button>
          </div>
        )}
      </main>

      {/* Floating Sticky Cart Tray if cart has items */}
      {cart.length > 0 && (
        <div className="fixed bottom-20 md:bottom-6 left-4 right-4 z-40 max-w-lg mx-auto">
          <div
            onClick={() => navigate('/cart')}
            className="bg-[#173F35] text-white p-3.5 rounded-2xl shadow-xl flex items-center justify-between cursor-pointer hover:bg-[#235B4E] transition-all transform hover:-translate-y-0.5 active:scale-[0.99] border border-emerald-900"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-900 flex items-center justify-center font-bold text-sm">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-sm">
                  {cartItemCount} ta taom savatda
                </span>
                <span className="text-xs text-white/80 tabular-nums">
                  Jami: {formatUZS(cartTotal)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-white/10 px-3 py-1.5 rounded-xl text-xs font-semibold">
              <span>Savatga o'tish</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      )}

      {/* Dish Detail Modal */}
      <DishDetailModal dish={selectedDish} onClose={() => setSelectedDish(null)} />

      {/* QR Code Showcase & Camera Scanner Modal */}
      <QrScannerModal
        isOpen={isQrModalOpen}
        onClose={() => setIsQrModalOpen(false)}
      />

      {/* Mobile Bottom Navigation */}
      <CustomerBottomNav />
    </div>
  );
};
